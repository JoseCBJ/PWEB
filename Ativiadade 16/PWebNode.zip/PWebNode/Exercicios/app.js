let express = require('express');
let app=express();
app.listen(3000, function(){
    console.log("servidor do express foi carregado com sucesso");
});